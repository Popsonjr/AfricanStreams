<?php

use App\Http\Controllers\AccountController;
use App\Http\Controllers\AdminAuthController;
use App\Http\Controllers\AuthController;
use App\Http\Controllers\CategoryController;
use App\Http\Controllers\EpisodeController;
use App\Http\Controllers\FavoriteController;
use App\Http\Controllers\GenreController;
use App\Http\Controllers\ListController;
use App\Http\Controllers\ListItemController;
use App\Http\Controllers\MovieController;
use App\Http\Controllers\RatingController;
use App\Http\Controllers\ReviewController;
use App\Http\Controllers\SeasonController;
use App\Http\Controllers\SeriesController;
use App\Http\Controllers\TvController;
use App\Http\Controllers\UploadController;
use App\Http\Controllers\WatchlistController;
use App\Models\Rating;
use App\Models\Watchlist;
use Illuminate\Support\Facades\Route;

use Illuminate\Http\Request;

Route::prefix('auth')->group(function () {
    Route::post('/register', [AuthController::class, 'register']);
    Route::post('/login', [AuthController::class, 'login']);
    Route::post('/logout', [AuthController::class, 'logout']);
    Route::post('/email/verify', [AuthController::class, 'verifyEmail']);
    Route::post('/email/resend', [AuthController::class, 'resendVerificationEmail']);
    Route::post('/refresh', [AuthController::class, 'refresh']);
    Route::post('/get-user', [AuthController::class, 'getUser']);
    Route::post('/password/reset-request', [AuthController::class, 'sendResetLink']);
    Route::post('/password/reset', [AuthController::class, 'resetPassword']);
    

    Route::middleware('auth:api')->group(function () {
        Route::post('/me', [AuthController::class, 'me']);
        Route::post('/password/change', [AuthController::class, 'changePassword']);

        
    });
    
    // Route::get('facebook/redirect', AuthController::class, 'redirectToFacebook');
    // Route::get('facebook/callback', AuthController::class, 'handleFacebookCallback');
});
Route::middleware('auth:api')->group(function () {
    Route::get('/account', [AccountController::class, 'details']);
    Route::get('/account/{account_id}/lists', [AccountController::class, 'lists']);
    Route::get('/account/{account_id}/favourite/movies', [AccountController::class, 'favoriteMovies']);
    Route::get('/account/{account_id}/favourite/tv', [AccountController::class, 'favoriteTv']);
    Route::post('/account/{account_id}/favourite', [AccountController::class, 'markAsFavorite']);
    Route::get('/account/{account_id}/rated/movies', [AccountController::class, 'ratedMovies']);
    Route::get('/account/{account_id}/rated/tv', [AccountController::class, 'ratedTv']);
    Route::get('/account/{account_id}/rated/tv/episodes', [AccountController::class, 'ratedEpisodes']);
    Route::get('/account/{account_id}/watchlist/movies', [AccountController::class, 'watchlistMovies']);
    Route::get('/account/{account_id}/watchlist/tv', [AccountController::class, 'watchlistTv']);
    Route::post('/account/{account_id}/watchlist', [AccountController::class, 'addToWatchlist']);

    // Route::post('/account/{account_id}/favourite', [FavoriteController::class, 'store']);
    // Route::post('/account/{account_id}/watchlist', [WatchlistController::class, 'store']);
    Route::post('/account/{account_id}/rating', [RatingController::class, 'store']);
    Route::post('/account/{account_id}/list', [ListController::class, 'store']);
    Route::post('/account/{account_id}/list/{list}/item', [ListItemController::class, 'store']);
});

Route::prefix('')->group(function () {
    // Movie Endpoints
    Route::post('/movie', [MovieController::class, 'store'])->middleware('auth:admin');
    Route::get('/movie/popular', [MovieController::class, 'popular']);
    Route::get('/movie/now_playing', [MovieController::class, 'nowPlaying']);
    Route::get('/movie/upcoming', [MovieController::class, 'upcoming']);
    Route::get('/movie/top_rated', [MovieController::class, 'topRated']);
    Route::get('/movie/{id}', [MovieController::class, 'details']);
    Route::get('/movie/{id}/account_states', [MovieController::class, 'accountStates'])->middleware('auth:api');
    Route::get('/movie/{id}/credits', [MovieController::class, 'credits']);
    Route::get('/movie/{id}/reviews', [MovieController::class, 'reviews']);
    Route::post('/movie/{id}/rating', [MovieController::class, 'rate'])->middleware('auth:api');
    Route::delete('/movie/{id}/rating', [MovieController::class, 'deleteRating'])->middleware('auth:api');
    

    // TV Show Endpoints
    Route::get('/tv/popular', [TvController::class, 'popular']);
    // Route::get('/tv/airing_today', [TvController::class, 'airingToday']);
    Route::get('/tv/on_the_air', [TvController::class, 'onTheAir']);
    Route::get('/tv/top_rated', [TvController::class, 'topRated']);
    Route::get('/tv/{id}', [TvController::class, 'details']);
    Route::get('/tv/{id}/account_states', [TvController::class, 'accountStates'])->middleware('auth:api');
    Route::get('/tv/{id}/credits', [TvController::class, 'credits']);
    Route::get('/tv/{id}/reviews', [TvController::class, 'reviews']);
    Route::post('/tv/{id}/rating', [TvController::class, 'rate'])->middleware('auth:api');
    Route::delete('/tv/{id}/rating', [TvController::class, 'deleteRating'])->middleware('auth:api');
    

    // Season Endpoints
    Route::get('/tv/{series_id}/season/{season_number}', [SeasonController::class, 'details']);
    Route::get('/tv/{series_id}/season/{season_number}/account_states', [SeasonController::class, 'accountStates'])->middleware('auth:api');
    Route::get('/tv/{series_id}/season/{season_number}/credits', [SeasonController::class, 'credits']);

    // Episode Endpoints
    Route::get('/tv/{series_id}/season/{season_number}/episode/{episode_number}', [EpisodeController::class, 'details']);
    Route::get('/tv/{series_id}/season/{season_number}/episode/{episode_number}/account_states', [EpisodeController::class, 'accountStates'])->middleware('auth:api');
    Route::get('/tv/{series_id}/season/{season_number}/episode/{episode_number}/credits', [EpisodeController::class, 'credits']);
    Route::post('/tv/{series_id}/season/{season_number}/episode/{episode_number}/rating', [EpisodeController::class, 'rate'])->middleware('auth:api');
    Route::delete('/tv/{series_id}/season/{season_number}/episode/{episode_number}/rating', [EpisodeController::class, 'deleteRating'])->middleware('auth:api');

    // Review Endpoints
    Route::get('/review/{review_id}', [ReviewController::class, 'details']);
});

// Genre Endpoints (Public)
Route::get('/genre/movie/list', [GenreController::class, 'movieGenres']);
Route::get('/genre/tv/list', [GenreController::class, 'tvGenres']);

// Genre Endpoints (Authenticated, Admin-Only)
Route::middleware('auth:admin')->group(function () {
    Route::post('/genre', [GenreController::class, 'store']);
    Route::put('/genre/{id}', [GenreController::class, 'update']);
    Route::delete('/genre/{id}', [GenreController::class, 'destroy']);
});

Route::prefix('admin')->group(function () {
    Route::post('/register', [AdminAuthController::class, 'register']);
    Route::post('/login', [AdminAuthController::class, 'login']);
    Route::post('/logout', [AdminAuthController::class, 'logout']);
    Route::post('/email/verify', [AdminAuthController::class, 'verifyEmail']);
    Route::post('/email/resend', [AdminAuthController::class, 'resendVerificationEmail']);
    Route::post('/refresh', [AdminAuthController::class, 'refresh']);
    Route::post('/password/reset-request', [AdminAuthController::class, 'sendResetLink']);
    Route::post('/password/reset', [AdminAuthController::class, 'resetPassword']);
    
    Route::apiResource('movies', MovieController::class);
    Route::get('movies/{id}/related', [MovieController::class, 'related']);
    
    Route::apiResource('categories', CategoryController::class);
    Route::apiResource('genres', GenreController::class);

    Route::middleware('auth:admin')->group(function () {
        Route::post('/me', [AdminAuthController::class, 'me']);
        Route::post('/get-user', [AdminAuthController::class, 'getUser']);
        Route::post('/password/change', [AdminAuthController::class, 'changePassword']);
        
        Route::post('/genres', [GenreController::class, 'store']);
        Route::put('/genres', [GenreController::class, 'update']);
        Route::delete('/genre', [GenreController::class, 'delete']);

        Route::post('/categories', [CategoryController::class, 'store']);
        Route::put('/categories', [CategoryController::class, 'update']);
        Route::delete('/categories', [CategoryController::class, 'delete']);
        
        Route::post('/movies', [MovieController::class, 'store']);
        Route::put('/movies', [MovieController::class, 'update']);
        Route::delete('/movies', [MovieController::class, 'delete']);
    });
});

//Route For Series
// Route::prefix('series')->group(function() {
//     Route::get('/', [SeriesController::class, 'index']);
//     Route::get('/{series}', [SeriesController::class, 'show']);
//     Route::middleware('auth:admin')->group(function () {
//         Route::post('/', [SeriesController::class, 'store']);
//         Route::put('/{series}', [SeriesController::class, 'update']);
//         Route::delete('/{series}', [SeriesController::class, 'destroy']);
//     });
// });

// //Route For Seasons within a Series
// Route::prefix('series/{series}')->group(function() {
//     Route::get('/seasons', [SeasonController::class, 'index']);
//     Route::get('/seasons/{season}', [SeasonController::class, 'show']);
//     Route::middleware('auth:admin')->group(function () {
//         Route::post('/seasons', [SeasonController::class, 'store']);
//         Route::put('/seasons/{season}', [SeasonController::class, 'update']);
//         Route::delete('/seasons/{season}', [SeasonController::class, 'destroy']);
//     });
// });

// //Route For Episodes within a Season
// Route::prefix('seasons/{season}')->group(function() {
//     Route::get('/episodes', [EpisodeController::class, 'index']);
//     Route::get('/episodes/{episode}', [EpisodeController::class, 'show']);
//     Route::middleware('auth:admin')->group(function () {
//         Route::post('/episodes', [EpisodeController::class, 'store']);
//         Route::put('/episodes/{episode}', [EpisodeController::class, 'update']);
//         Route::delete('/episodes/{episode}', [EpisodeController::class, 'destroy']);
//     });
// });



// Route::options('{any}', function (Request $request) {
//     return response()->noContent(204)
//         ->withHeaders([
//             'Access-Control-Allow-Origin' => $request->header('Origin') ?? '*',
//             'Access-Control-Allow-Methods' => 'GET, POST, PUT, DELETE, OPTIONS',
//             'Access-Control-Allow-Headers' => $request->header('Access-Control-Request-Headers') ?? 'Origin, Content-Type, Accept, Authorization',
//         ]);
// })->where('any', '.*');