<p>Click the link below to reset your password:</p>
<a href="{{ env('APP_URL') }}/reset-password?token={{$token}}">Reset Password</a>