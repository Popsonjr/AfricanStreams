<p>Click the link below to verify your email:</p>
<a href="{{ env('APP_URL') }}/verify?token={{ $token }}">Verify Email</a>